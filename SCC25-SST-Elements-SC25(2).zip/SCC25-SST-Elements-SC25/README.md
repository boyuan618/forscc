# SST-Elements for IndySCC and SCC at SC25

For the SST the code you will use is from the upstream repos:
- <https://github.com/sstsimulator/sst-core>
- <https://github.com/sstsimulator/sst-elements>

There is a clone of each of these on your fileserver, that you can copy or clone.

Per Patrick's message in the Google group "For now you should pull from the devel branch
for both core and elements on the sstsimulator GitHub page".

This repo has the [instructions](SCC_Problems.pdf) and supporting scripts etc.

Use the "Issues" tab in this repo to ask questions, and to browse already-asked questions.

